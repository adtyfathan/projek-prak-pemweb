<?php
$koneksi = mysqli_connect("localhost", "root", "", "projek_praktikum") or die("gagal koneksi");
?>